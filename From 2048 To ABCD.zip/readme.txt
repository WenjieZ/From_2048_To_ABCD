From 2048 To ABCD

===================================================================================

* Introduction

This game is a variant of the popular game 2048. Alphabets are used instead of numbers (A=2, B=4, C=8,...). Besides that, the mechanism has also been changed. In the original game, you will only see the new occurrence of "2" or "4" (with slight probability). In this game, you will be able to see the occurrence of larger numbers such as "C"(=8), "D"(=16) and so on. Do not jump to the conclusion that it becomes easier. In fact, the game could become quite unpredictable, and thus brings you a challenge. 

===================================================================================

# How to play

Use the arrow keys. 

There is no win. Once you get "K"(=2048), you can try further to get "L"(=4096)...

There is no lost, either. If you have filled all squares and find no more match, just move on, and the up-left corner will changes. 

